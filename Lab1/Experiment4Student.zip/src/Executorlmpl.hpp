#pragma once

#include "Executor.hpp"
#include<string>

namespace adas{
    class ExecutorImpl : public Executor{
        public:
            //构造和析构函数
            explicit ExecutorImpl(const Pose& pose) noexcept;
            ~ExecutorImpl() noexcept=default;

            //不能拷贝
            ExecutorImpl(const ExecutorImpl&)=delete;
            //不能赋值
            ExecutorImpl& operator=(const ExecutorImpl&)=delete;
        
        public:
            Pose Query(void) const noexcept override;
            void Execute(const std::string& commands) noexcept override;
        private:
        //当前姿态
            Pose pose;
    };
}