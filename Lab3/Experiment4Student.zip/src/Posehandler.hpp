#pragma once

#include"Executor.hpp"
#include"Direction.hpp"

namespace adas{

    class PoseHandler final{
        public:
            PoseHandler(const Pose& pose) noexcept;
            PoseHandler(const PoseHandler&)=delete;
            PoseHandler& operator=(const PoseHandler&)=delete;
        
        public:
            bool IsFast(void) const noexcept;  //查询是否快速模式
            bool IsReverse(void) const noexcept;  //查询是否快速模式
            
            void Fast(void) noexcept;  //切换快速模式
            void Reverse(void) noexcept;  //切换快速模式

            void Forward(void) noexcept;            
            void Backward(void) noexcept;   

            void TurnLeft(void) noexcept;
            void TurnRight(void) noexcept;

            Pose Query(void) const noexcept;  //查询当前位置
            
        private:
            Point point;
            const Direction* facing;
            bool fast{false};   //当前是否快速状态
            bool reverse{false};   //当前是否倒车状态
    };
}
