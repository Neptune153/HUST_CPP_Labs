#pragma once
#include"Command.hpp"
#include"Executor.hpp"
#include"PoseHandler.hpp"
#include<string>    

namespace adas{
    class ExecutorImpl final : public Executor{
    public:
        //构造和析构函数
        explicit ExecutorImpl(const Pose& pose) noexcept;
        ~ExecutorImpl() noexcept=default;

        //不能拷贝
        ExecutorImpl(const ExecutorImpl&)=delete;
        //不能赋值
        ExecutorImpl& operator=(const ExecutorImpl&)=delete;

    private:
        PoseHandler poseHandler;  //姿态处理器

    public:
        Pose Query(void) const noexcept override;
        void Execute(const std::string& commands) noexcept override;

    };
}//namespace adas