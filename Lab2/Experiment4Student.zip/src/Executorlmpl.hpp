#pragma once

#include "Executor.hpp"
#include<string>    

namespace adas{
    class ExecutorImpl final : public Executor{
    public:
        //构造和析构函数
        explicit ExecutorImpl(const Pose& pose) noexcept;
        ~ExecutorImpl() noexcept=default;

        //不能拷贝
        ExecutorImpl(const ExecutorImpl&)=delete;
        //不能赋值
        ExecutorImpl& operator=(const ExecutorImpl&)=delete;
        
    public:
        Pose Query(void) const noexcept override;
        void Execute(const std::string& commands) noexcept override;
    private:
        Pose pose;      //当前姿态
        bool fast{false};   //当前是否快速状态

        void Fast(void) noexcept;  //切换快速模式
        bool IsFast(void) const noexcept;  //查询是否快速模式

        void Move(void) noexcept;
        void TurnLeft(void) noexcept;
        void TurnRight(void) noexcept;

        class ICommand{
        public:
            virtual void DoOperate(ExecutorImpl& executor) const noexcept=0;
            virtual ~ICommand()=default;
        };

        class FastCommand final : public ICommand{
        public:
            void DoOperate(ExecutorImpl& executor) const noexcept override{
                executor.Fast();
            }
        };

        class MoveCommand final : public ICommand{
        public:
            void DoOperate(ExecutorImpl& executor) const noexcept override{
                if(executor.IsFast())
                    executor.Move();
                executor.Move();
            }
        };

        class TurnLeftCommand final : public ICommand{
        public:
            void DoOperate(ExecutorImpl& executor) const noexcept override{
                if(executor.IsFast())
                    executor.Move();
                executor.TurnLeft();
            }
        };

        class TurnRightCommand final : public ICommand{
        public:
            void DoOperate(ExecutorImpl& executor) const noexcept override{
                if(executor.IsFast())
                    executor.Move();
                executor.TurnRight();
            }
        };
    };
}//namespace adas