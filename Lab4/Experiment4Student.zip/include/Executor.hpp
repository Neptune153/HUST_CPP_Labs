#pragma once //防止头文件被多次包含，简化代码，避免重复定义和编译错误
#include <string>
namespace adas//组织代码并防止命名冲突，使代码更易于管理和阅读
{
    enum class ExecutorType {
        NORMAL,
        SPORTS_CAR,
        BUS,
    };


    struct Pose { //在计算和计算机视觉领域，pose (或 spatial pose) 表示物体的位置和方向
        int x;
        int y;
        char heading;
    }; //定义结构体，便于数据的组织和传递

    class Executor  //抽象类，提供接口定义，隐藏功能实现细节
    {   
    public:
        static Executor* NewExecutor(const Pose& pose = {0, 0, 'N'},
            const ExecutorType executorType = ExecutorType::NORMAL) noexcept;  //静态成员函数，无需实例化即可调用，工厂方法模式
    public:
        Executor(void) = default;   //简化代码，明确表示使用编译器生成的默认实现
        virtual ~Executor(void) = default;
        Executor(const Executor&) = delete; //防止对象的拷贝
        Executor& operator=(const Executor&) = delete; //防止对象的赋值
    public:
        //virtual void Execute(conststd::string& command) = 0; 
        virtual Pose Query(void) const noexcept= 0;
        virtual void Execute(const std::string& commands) noexcept= 0;
    };
} // namespace adas