#include "Executorlmpl.hpp" 
#include"core/Singleton.hpp"
#include"cmder/CmdFactory.hpp"
#include"cmder/NormalOrchestrator.hpp"
#include"cmder/BusOrchestrator.hpp"
#include"cmder/SportsCarOrchestrator.hpp"

#include<algorithm>


namespace adas{
    using Cmder=std::function<ActionGroup(const PoseHandler& poseHandler,const CmderOrchestrator& orchestrator)>;
    Executor* Executor::NewExecutor(const Pose& pose,const ExecutorType executortype) noexcept{
        CmderOrchestrator* orchestrator=nullptr;
        switch(executortype){
            case ExecutorType::NORMAL:{
                orchestrator=new(std::nothrow) NormalOrchestrator();
                break;
            }
            case ExecutorType::BUS:{
                orchestrator=new(std::nothrow) BusOrchestrator();
                break;
            }
            case ExecutorType::SPORTS_CAR:{
                orchestrator=new(std::nothrow) SportsCarOrchestrator();
                break;
            }
        }
        return new(std::nothrow) ExecutorImpl(pose,orchestrator);
    };


    ExecutorImpl::ExecutorImpl(const Pose& pose,CmderOrchestrator* orchestrator) noexcept : poseHandler(pose),orchestrator(orchestrator){}
    

    void ExecutorImpl::Execute(const std::string& commands) noexcept{

        const auto cmders=Singleton<CmdFactory>::Instance().GetCmders(commands);

        std::for_each(cmders.begin(),cmders.end(),
            [this](const Cmder& cmder) noexcept{   cmder(poseHandler,*orchestrator).DoOperate(poseHandler);});   
    }
    Pose ExecutorImpl::Query(void) const noexcept{
        return poseHandler.Query();
    }



}