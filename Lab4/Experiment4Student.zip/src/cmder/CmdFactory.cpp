#include "CmdFactory.hpp"



namespace adas {

    CmderList CmdFactory::GetCmders(const std::string& commands) const noexcept {
        CmderList commandList;

        for (const auto& cmd:ParseCommandString(commands)) {
            auto it = cmderMap.find(cmd);
            if (it != cmderMap.end()) {
                commandList.push_back(it->second); // 添加对应的命令
            }
        }

        return commandList; // 返回生成的命令列表
    }

    std::string CmdFactory::ParseCommandString(std::string_view commands) const noexcept {
        std::string result(commands);

        ReplaceAll(result,"TR","Z");
        return result;
    }

    void CmdFactory::ReplaceAll(std::string& inout,  std::string_view what,  std::string_view with) const noexcept {
        for(
            std::string::size_type pos{};
            inout.npos!=(pos=inout.find(what.data(),pos, what.length()));
            pos+=with.length()
        ){
            inout.replace(pos,what.length(),with.data(),with.length());
        }
    }
}
